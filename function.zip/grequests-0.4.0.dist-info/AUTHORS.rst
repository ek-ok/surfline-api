GRequests is written and maintained by Kenneth Reitz and
various contributors:

Development Lead
````````````````

- Kenneth Reitz <me@kennethreitz.com>

Patches and Suggestions
```````````````````````
- Kracekumar <me@kracekumar.com>
- Spencer Young <spencer.young@spyoung.com>
